/**************************************************************************************************/
/* Copyright (C) SSE@USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Wangchenyang                                                         */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wangchenyang, 2014/09/29
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"menu.h"


tLinkTable * front = NULL;

/* Inite menu data */
int InitMenuData(tMenuNode * data)
{
    if(front==NULL)
    {
	return SUCCESS;
    }
    return FAILURE;
}

/*Find the corresponding cmd */
tDataNode * FindCmd(char * cmd)
{
    return NULL;
}

/* Show all cmd in linktable */
int ShowAllCmd()
{
    if(front == NULL)
    {
	return FAILURE;
    }
    return SUCCESS;
}

/* Add menu node */
int AddMenuNode(tMenuNode * menuNode)
{
    if(menuNode == NULL || FindCmd(menuNode->cmd) == NULL)
    {
	return FAILURE;
    }
    return SUCCESS;
}

/* Delete menu node */
int DeleteMenuNode(char * cmd)
{
    if(cmd == NULL || FindCmd(cmd) == NULL)
    {
	return FAILURE;
    }
    return SUCCESS;
}


