/**************************************************************************************************/
/* Copyright (C) SSE@USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Wangchenyang                                                         */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  interface of menu.c                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wangchenyang, 2014/09/29
 *
 */

#include <stdio.h>
#include <stdlib.h>

#define CMD_MAX_LEN  128
#define DESC_LEN     1024
#define CMD_NUM      10
#define SUCCESS      0
#define FAILURE      1

typedef struct LinkTableNode
{
    struct LinkTableNode * pNext;
}tLinkTableNode;

typedef struct DataNode
{
    tLinkTableNode * pNext;
    char*    cmd;
    char*    desc;
    int      (*handler)();
}tDataNode;

typedef struct MenuNode
{
    struct MenuNode * next;
    char   *cmd;
    char   *desc;
    int    (*handler)();
}tMenuNode;

typedef struct LinkTable
{
    
}tLinkTable;

/* InitMenuData cmd */
int InitMenuData(tMenuNode * data);

/* Show all the command */
int ShowAllCmd();

/* Find the corresponding cmd */
tDataNode* FindCmd(char * cmd);

/* Add menu node */
int AddMenuNode(tMenuNode * menuNode);

/* Delete menu node */
int DeleteMenuNode(char * cmd);


