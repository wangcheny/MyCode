
/**************************************************************************************************/
/* Copyright (C) SSE@USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Wangchenyang                                                         */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  interface of menu.c                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wangchenyang, 2014/09/21
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "linktable.h"

#define CMD_MAX_LEN  128
#define DESC_LEN     1024
#define CMD_NUM      10

/* data struct and its operation */
typedef struct DataNode
{
    tLinkTableNode * pNext;
    char*    cmd;
    char*    desc;
    int      (*handler)();
}tDataNode;

typedef struct MenuNode
{
    struct MenuNode * next;
    char   *cmd;
    char   *desc;
    int    (*handler)();
}tMenuNode;

/* show the help list */
int Help();

/*Initialize cmd*/
tLinkTable* Initialize();

/* show all the command */
int ShowAllCmd();

/*find the corresponding cmd*/
tDataNode* FindCmd();

/* show wrong command */
int Wrong();

/* quit the menu program */
int Quit();

