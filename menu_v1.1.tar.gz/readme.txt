This is a menu program!

Build Procedure
	$ gcc test.c linktable.c menu.c -o test
	$ ./test # you can input help & version & quit cmd.
